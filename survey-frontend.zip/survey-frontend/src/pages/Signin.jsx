// src/pages/Signin.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Signin.css';
const Signin = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: Implement signin logic
    console.log('Signin submitted:', formData);
  };

  return (
    <div className="signin-page-container">
      <div className="signin-card">
        <h2 className="signin-title">Sign In</h2>
        <form onSubmit={handleSubmit} className="signin-form">
          <div className="signin-form-group">
            <label className="signin-form-label">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="signin-form-input"
              required
            />
          </div>
          <div className="signin-form-group">
            <label className="signin-form-label">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="signin-form-input"
              required
            />
          </div>
          <button
            type="submit"
            className="signin-form-submit"
          >
            Sign In
          </button>
        </form>
        <p className="signin-form-footer">
          Don't have an account? <Link to="/signup" className="signin-form-link">Sign Up</Link>
        </p>
      </div>
    </div>
  );
};

export default Signin;