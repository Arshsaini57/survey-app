// src/pages/Signup.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Signup.css';
const Signup = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: Implement signup logic
    console.log('Signup submitted:', formData);
  };

  return (
    <div className="signup-page-container">
      <div className="signup-card">
        <h2 className="signup-title">Sign Up</h2>
        <form onSubmit={handleSubmit} className="signup-form">
          <div className="signup-form-group">
            <label className="signup-form-label">Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="signup-form-input"
              required
            />
          </div>
          <div className="signup-form-group">
            <label className="signup-form-label">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="signup-form-input"
              required
            />
          </div>
          <div className="signup-form-group">
            <label className="signup-form-label">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="signup-form-input"
              required
            />
          </div>
          <div className="signup-form-group">
            <label className="signup-form-label">Confirm Password</label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              className="signup-form-input"
              required
            />
          </div>
          <button
            type="submit"
            className="signup-form-submit"
          >
            Sign Up
          </button>
        </form>
        <p className="signup-form-footer">
          Already have an account? <Link to="/login" className="signup-form-link">Sign In</Link>
        </p>
      </div>
    </div>
  );
};

export default Signup;